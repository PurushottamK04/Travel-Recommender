from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import os
from myapp.planner import planning
# Create your views here.
def home(request):
    return JsonResponse({'info': 'Hello World!'})

@csrf_exempt
def planner(request):
    # POST request
    if request.method == 'POST':
        # Get the data from the request
        data = json.loads(request.body)
        print("POST request")
        # Get the query string
        station_names = []
        days = {}
        Q = None
        state = None
        for key, value in data.items():
            if key == 'Q':
                Q = value
                continue
            if key == 'state':
                state = value
                continue
            station_names.append(key)
            days[key] = value
        if state == None:
            return JsonResponse({'error': 'State not provided'})
        if Q == None:
            return JsonResponse({'error': 'Q not provided'})
        print(station_names, days)
        out = planning(state,station_names, days, Q)
        map_html_link = os.path.join(os.getcwd(), 'map.html')
        return JsonResponse({'plan': out, 'map_html': map_html_link})
